"""
   __    _    __    __             _ ___
  / /__ (_)__/ /__ / /  ___  ___  (_) _/_ __
 /  '_// / _  /_ // _ \/ _ \/ _ \/ / _/ // /
/_/\_\/_/\_,_//__/_.__/\___/ .__/_/_/ \_, /
                          /_/        /___/
      By: Mr Juice
"""
import argparse
import random
import time



print("   __    _    __    __             _ ___")
print("  / /__ (_)__/ /__ / /  ___  ___  (_) _/_ __")
print(" /  '_// / _  /_ // _ \/ _ \/ _ \/ / _/ // /")
print("/_/\_\/_/\_,_//__/_.__/\___/ .__/_/_/ \_, /")
print("                          /_/        /___/")
print("      By: Mr Juice")

new_arse = random.choice(["back", "arm", "can", "phone", "car"])
new_ass = random.choice(["back", "arm", "can", "phone", "car"])
new_alcohol = random.choice(["flat soda"])
new_bastard = random.choice(["meanie"])
new_bitch = random.choice(["dude"])
new_bollocks = random.choice(["rice cake"])
new_bugger = random.choice(["big boi"])
new_balls = random.choice(["bags"])
new_christ = random.choice(["cool"])
new_crap = random.choice(["stuff"])
new_cunt = random.choice(["clam", "plum"])
new_cum = random.choice(["love"])
new_damn = random.choice(["darn", "dang"])
new_drug = random.choice(["game"])
new_dick = random.choice(["duck"])
new_drink = random.choice(["sip", "taste"])
new_fuck = random.choice(["frick", "kiss", "hug", "love"])
new_god = random.choice(["gosh"])
new_gang = random.choice(["group", "friends"])
new_hell = random.choice(["heck", "sea"])
new_ho = random.choice(["girl "])
new_jesus = random.choice(["sugar", "father"])
new_jizz = random.choice(["juice"])
new_nigga = random.choice(["homie", "friendo"])
new_nigger = random.choice(["meanie"])
new_nut = random.choice(["dream"])
new_prick = random.choice(["jerk"])
new_shit = random.choice(["poo"])
new_sex = random.choice(["love"])
new_slut = random.choice(["girl"])
new_twat = random.choice(["girl"])
new_thot = random.choice(["girl"])
new_tits = random.choice(["toys", "gifts"])
new_whore = random.choice(["girl"])
new_skank = random.choice(["girl"])
new_virgin = random.choice(["baby"])
new_smoke = random.choice(["breath"])
new_cuck = random.choice(["nerd"])
new_rape = random.choice(["hug", "love"])
new_raping = random.choice(["rapping"])
new_phat = random.choice(["nice", "big"])
new_gun = random.choice(["bun", "cake"])
new_bullet = random.choice(["pellet", "sprinkle"])
new_pussy = random.choice(["oyster"])

parser = argparse.ArgumentParser(description="Kidzbobifies Text files")
group = parser.add_mutually_exclusive_group()
parser.add_argument('-f', '--f_dir', help="The location of the text file you are looking to modify")
parser.add_argument('-s', '--settings', help="Changes the settings found in Settings.txt")
args = parser.parse_args()


def Kidzbopify(f_dir):
    with open("Settings.txt", "r") as sf:
        sf_raw = sf.read()
        place = sf_raw.find("floading")
        place += 3
        place += len("floading")
        num = sf_raw[place]
        if num == 1:
            floading = True
        else:
            floading = False
        sf_raw = sf.read()
        place = sf_raw.find("eggs")
        place += 2
        place += len("eggs")
        num = sf_raw[place]
        if num == 1:
            eggs = True
        else:
            eggs = False



    if eggs:
        if "dqw4w9wgxcq" in f_dir:
            print(r"""
              ………………………………………………………………………………„-~~'''''''~~--„„_
          …………………………………………………………………………„-~''-,:::::::::::::::::::''-„
          …………………………………………………………………….,~''::::::::',::::::::::::::::::::|',
          …………………………………………………………………….|::::::,-~'''¯¯¯''''~~--~'''¯'''-,:|
          …………………………………………………………………….'|:::::|: : : : : : : : : : : : : |,'
          …………………………………………………………………….|:::::|: : :-~~---: : : -----: |
          ……………………………………………………………………(¯''~-': : : :'¯°: ',: :|: :°-: :|
          …………………………………………………………………….'''~-,|: : : : : : ~---': : : :,'
          ………………………………………………………………………..|,: : : : : :-~~--: : ::/
          ……………………………………………………………………,-''\':\: :'~„„_: : : : : _,-'
          ………………………………………………………………__„-';;;;;\:''-,: : : :'~---~''/|
          ………………………………………………………__„-~'';;;;;;/;;;;;;;\: :\: : :____/: :',__
          ……………………………………………„-~~~''''¯;;;;;;;;;;;;;;;;;;;;;;;;;',. .''-,:|:::::::|. . |;;;;''-„__
          …………………………………………../;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;;;;;\. . .''|::::::::|. .,';;;;;;;;;;''-„
          …………………………………………,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|;;;;;;;;;;;\. . .\:::::,'. ./|;;;;;;;;;;;;;|
          ………………………………………,-'';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\;;;;;;;;;;;',: : :|¯¯|. . .|;;;;;;;;;,';;|
          …………………………………….„-";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;',;;;;;;;;;;;\. . |:::|. . .'',;;;;;;;;|;;/
          ……………………………………/;;;;;;;;;;;;;;;;;;;;;;;;;;|;;;;;;;;;;;;;;\;;;;;;;;;;;\. .|:::|. . . |;;;;;;;;|/
          …………………………………./;;,-';;;;;;;;;;;;;;;;;;;;;;,';;;;;;;;;;;;;;;;;,;;;;;;;;;;|. .\:/. . . .|;;;;;;;;|
          …………………………………/;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;'',: |;|. . . . \;;;;;;;|
          ………………………………„~'';;;;;;;;;;;;;;;;;;;;;,-'';;;;;;;;;;;;;;;;;;;;;;;;;;\;;;;;;;;|.|;|. . . . .|;;;;;;;|
          …………………………..„~'';;;;;;;;;;;;;;;;;;;;;;,-';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;',;;;;;;| |:|. . . . |\;;;;;;;|
          ………………………….,';;;;;;;;;;;;;;;;;;;;;;;;/;;;,-';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;| |:|. . . .'|;;',;;;;;|
          …………………………|;,-';;;;;;;;;;;;;;;;;;;,-';;;,-';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;| |:|. . .,';;;;;',;;;;|_
          …………………………/;;;;;;;;;;;;;;;;;,-'_;;;;;;,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|;;;;|.|:|. . .|;;;;;;;|;;;;|''''~-„
          ………………………./;;;;;;;;;;;;;;;;;;/¯'',;;;,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;| |:|. . ./;;;;;;;;|;;;|;;;;;;|-„„__
          ……………………../;;;;;;;;;;;;;;;;;,-'…|;;,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;| |:|._,-';;;;;;;;;|;;;;|;;;;;;;;;;;'''-„_
          ……………………/;;;;;;;;;;;;;;;;,-'….,';;,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|.|:|::::'''~--~'''||;;;;;|;;;;;;;;;;,-~''''~--„______
          ………………….,';;;;;;;;;;;;;;;;,'……/;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|.|:|::::::::::::::|;;;;;',;;;;;;;;;''-,: : : : : :'''~-,:'''~~--„
          …………………/;;;;;;;;;;;;;;;,-'……,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|:|:|::::::::::::::',;;;;;;|¯''''~--„„-~---„„___„-~~'''__''~-\
          ………………,-';;;;;;;;;;;;;;;,'……../ ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|:|:|:::::::::::::::|;;;;;
          md…..……../;;;;;;;;;;;;;;;;/…….,-;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|:|:|:::::::::::::::|;;;
              """)

        elif "lightswitch" in f_dir.lower():
            print(r"""
           .----------.
           |   ~on~   |
           |   ____   |
           |  |.--.|  |
           |  ||  ||  |
           |  ||__||  |
           |  ||\ \|  |
           |  |\ \_\  |
           |  |_\[_]  |
           |          |
           |  ~off~   |
           '----------'
              """)

        elif "forehead" in f_dir.lower():
            print(r"""
            .................................  .......                   .
         .,,,,,,,,,,,,,,,,,,,,,,'',,,'',,,,'.'',,,,,,,,,,,,,,,,,,,,,,,,,,.
         ';,,,,,,,,,,,,,,,,,;;;;;:clc:,,,''''''',,,;;,,,,,,,,,,,,,,,,,,,,.
         ';,,,,,,,,,,,,,;,',:;;;:::c::;;;,,,,',,'',;;;;;;;;,,,,,,,,,,,,,,.
         ';,,,,,,,,,;;;;,,,;:cc:;;;;;;;;;:::clooc,,,;;;;;;;;;;;,,,,,,,,,,.
         ';,,,,,,;;;;;;''.':::;,'',;cldxkoo0kkkkkkc;;;;;;;;;;;;;;;,,,,,,,.
         ';,,,,;;;;;;,,,,,;:;;;;coxk0kkkkkkkkkkkkkol:;;;;;;;;;;;;;;;;,,,,.
         ';,,;;;;;;:;,,;;;,;:::oo00kkkkkkkkkkkkkkkxo:,;;:::;;;;;;;;;;;;,;.
        .';;;;;;;:::,,ccc:lddxk0kkkxxkkkkkkkkkkkkkkxk:';::::::;;;;;;;;;;;.
        .,;;;;;::::;,:llco0kkkkkxxxxxkkkkkkkkkkkkkkkkx;,:cc:::::;;;;;;;;;.
        .,;;;::::::;,:clcdkkkxxxxxxxxxkkkkkkkkkkkkkk00d;:ccc:cc:::;;;;;;;.
        .,:;::::::cc;;:c::kkkkxxxxxxxxkkkkkkkkkkkko:''::clcccd0dc::;;;;;;.
        .,:::::::cccc;;::;l0kkkkkkkkkkkkkkkkkk0d;..,cll:clddlxkkc:::::;;;.
        .;:::::cccccc:;;:;c0kkkkk000oookkkkok0l',:ldkoklclkkololc::::::;;.
        .;::::ccccccll:;;;o0kkoo;'''....'';d0ool:':c:lxxocclokooccc::::;:.
        .;:::ccccccllll:,,:okk:;cccccc:ldxk0kodl:;ldld0odl:lokooccccc::::.
        .;ccccccccllllccol:o0okooooookolkoo0x0ddxxkkokxkxlclllllllccc::::.
        .:ccccccclllll:ldxdlokkk0okkkxxko00kxxookxxxxxxxklcllllllccccc:::.
        .:cccccclllllc:okxdokkxxxxxxxxxkk0kkkkko0kxxxxxxolcolllllllcccc::'
        .:ccccclllllllcd0oxod0kxxxxxxxxkkkkkk0k0o0kkkkkx0lcolllllllcccc::'
        .:cccccllllllllldo0kokkkkxxxxxkkoxk00000oxdokkkkkdcllllllllcccc::'
        .:ccccllllllllllccdkdx00kkkkk0o0kdxxdxokxdkkxodokdllllllllccccc::'
        .:ccccllllllllllllcoooo0kkkk00kkkxkk0okkxkkkdokk0ocllllllccccc:::.
        .::cccclllllllllllllccx00kkkdxdxkkxkokoo0kkodoxkxclllllllcccc::::.
        .:::cccclllllllllllllcok00kk0koldxdxkkkxdodk0xx0lcllllllcccc:::::.
        .:::ccccllllllllllllllllxo00kkkkokxl:;,;:lkkxxxxclllllcccccc::::;.
        .;:::cccccllllllllllllllclxo00kkkkkkkokxxk0kxx0lclccllccccc::::;;.
        .;::::ccccclllllllllllllccddxk0kkkkkkk0000kkxxkllc::::;,;::::;;;;.
        .;;;::::ccccccclllllllllclkoxxkkko0kkkkkkkkkkoolllc;',;;;,';:;;;;.
        .;;;;::::cccccccccclllllclkooookxxxxko0000ooxlclccc:;:::,,,;;;;;;.
        .;;;;;:::::cccccccccclllcooooooooookxxxxddxxdcccccc:::::::;;;;;;;.
        .,;;;;;;:::::cccccccccc,:xoo0oo000oooooxxkooo:::c:::::::;;;;;;;;;.
        .,;;;;;;;;;:::::cccc:;..,dko00oo000000kxko0oxo,';::::;;;;;;;;;;,;.
        .,,,,;;;;;;;;:::::;'.   ..;do00000kk000000k000c.....',;;;;;,;,,,,.
        .,,,,,,;;;;;;,''...      ...;d0k0o0kkkkkkkkkk0:..    ....''''',,,.
        .,,,,,,,''....     ...........;oo00kkkkkkkkkko.........   ........
        .''........ ....................',:ok0kkkkkoc....................
        .....................................,:looc,.....................
              """)

    try:
        with open(f_dir, 'r') as f:

            f_dir_fin = f_dir.replace(".txt", "_clean_version.txt")

            print(f_dir_fin)
            f_doc = f.read()
            f_cont = f_doc.lower()
            f_cont = f_cont.replace("arse", new_arse)
            f_cont = f_cont.replace("ass", new_ass)
            f_cont = f_cont.replace("alcohol", new_alcohol)
            f_cont = f_cont.replace("bastard", new_bastard)
            f_cont = f_cont.replace("bitch", new_bitch)
            f_cont = f_cont.replace("bollocks", new_bollocks)
            f_cont = f_cont.replace("bugger", new_bugger)
            f_cont = f_cont.replace("balls", new_balls)
            f_cont = f_cont.replace("christ", new_christ)
            f_cont = f_cont.replace("crap", new_crap)
            f_cont = f_cont.replace("cunt", new_cunt)
            f_cont = f_cont.replace("cum", new_cum)
            f_cont = f_cont.replace("damn", new_damn)
            f_cont = f_cont.replace("drug", new_drug)
            f_cont = f_cont.replace("dick", new_dick)
            f_cont = f_cont.replace("drink", new_drink)
            f_cont = f_cont.replace("fuck", new_fuck)
            f_cont = f_cont.replace("god", new_god)
            f_cont = f_cont.replace("gang", new_gang)
            f_cont = f_cont.replace("hell", new_hell)
            f_cont = f_cont.replace("ho ", new_ho)
            f_cont = f_cont.replace("jesus", new_jesus)
            f_cont = f_cont.replace("jizz", new_jizz)
            f_cont = f_cont.replace("nigga", new_nigga)
            f_cont = f_cont.replace("nigger", new_nigger)
            f_cont = f_cont.replace("nut", new_nut)
            f_cont = f_cont.replace("prick", new_prick)
            f_cont = f_cont.replace("shit", new_shit)
            f_cont = f_cont.replace("sex", new_sex)
            f_cont = f_cont.replace("slut", new_slut)
            f_cont = f_cont.replace("twat", new_twat)
            f_cont = f_cont.replace("thot", new_thot)
            f_cont = f_cont.replace("tits", new_tits)
            f_cont = f_cont.replace("whore", new_whore)
            f_cont = f_cont.replace("skank", new_skank)
            f_cont = f_cont.replace("virgin", new_virgin)
            f_cont = f_cont.replace("smoke", new_smoke)
            f_cont = f_cont.replace("cuck", new_cuck)
            f_cont = f_cont.replace("rape", new_rape)
            f_cont = f_cont.replace("raping", new_raping)
            f_cont = f_cont.replace("phat", new_phat)
            f_cont = f_cont.replace("gun", new_gun)
            f_cont = f_cont.replace("bullet", new_bullet)
            f_cont = f_cont.replace("pussy", new_pussy)

        with open(f_dir_fin, "w") as f2:
            f2.write(f_cont)
            if not floading:
                print("Loading...")
                time.sleep(5)
            print("Successfully Kidzbopified")
            print(f_dir_fin)

    except:
        print("No Text File Found!")
        print("Try Again!")


def settings(setting):
    with open("Settings.txt", "r") as sf:
        sf_raw = sf.read()
        place = sf_raw.find(setting)
        place += 3
        place += len(setting)
        num = sf_raw[place]
        value = 1
        if int(num) == 1:
            value = 0
        sf_raw1 = sf_raw[:place]
        sf_raw2 = sf_raw[place+1:]
        sf_raw = sf_raw1 + str(value) + sf_raw2
    with open("Settings.txt", "w") as sf:
        sf.write(sf_raw)


if __name__ == "__main__":
    if args.f_dir is not None:
        Kidzbopify(args.f_dir)
    else:
        settings(args.settings)

