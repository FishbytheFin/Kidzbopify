"""
   __    _    __    __             _ ___
  / /__ (_)__/ /__ / /  ___  ___  (_) _/_ __
 /  '_// / _  /_ // _ \/ _ \/ _ \/ / _/ // /
/_/\_\/_/\_,_//__/_.__/\___/ .__/_/_/ \_, /
                          /_/        /___/
      By: Mr Juice
"""

import random

print("   __    _    __    __             _ ___")
print("  / /__ (_)__/ /__ / /  ___  ___  (_) _/_ __")
print(" /  '_// / _  /_ // _ \/ _ \/ _ \/ / _/ // /")
print("/_/\_\/_/\_,_//__/_.__/\___/ .__/_/_/ \_, /")
print("                          /_/        /___/")
print("      By: Mr Juice")

new_arse = random.choice(["back", "arm", "can", "phone", "car"])
new_ass = random.choice(["back", "arm", "can", "phone", "car"])
new_alcohol = random.choice(["flat soda"])
new_bastard = random.choice(["meanie"])
new_bitch = random.choice(["dude"])
new_bollocks = random.choice(["rice cake"])
new_bugger = random.choice(["big boi"])
new_balls = random.choice(["bags"])
new_christ = random.choice(["cool"])
new_crap = random.choice(["stuff"])
new_cunt = random.choice(["clam", "plum"])
new_cum = random.choice(["love"])
new_damn = random.choice(["darn", "dang"])
new_drug = random.choice(["game"])
new_dick = random.choice(["duck"])
new_drink = random.choice(["sip", "taste"])
new_fuck = random.choice(["frick", "kiss", "hug", "love"])
new_god = random.choice(["gosh"])
new_gang = random.choice(["group", "friends"])
new_hell = random.choice(["heck", "sea"])
new_ho = random.choice(["girl "])
new_jesus = random.choice(["sugar", "father"])
new_jizz = random.choice(["juice"])
new_nigga = random.choice(["homie", "friendo"])
new_nigger = random.choice(["meanie"])
new_nut = random.choice(["dream"])
new_prick = random.choice(["jerk"])
new_shit = random.choice(["poo"])
new_sex = random.choice(["love"])
new_slut = random.choice(["girl"])
new_twat = random.choice(["girl"])
new_thot = random.choice(["girl"])
new_tits = random.choice(["toys", "gifts"])
new_whore = random.choice(["girl"])
new_skank = random.choice(["girl"])
new_virgin = random.choice(["baby"])
new_smoke = random.choice(["breath"])
new_cuck = random.choice(["nerd"])
new_rape = random.choice(["hug", "love"])
new_raping = random.choice(["rapping"])
new_phat = random.choice(["nice", "big"])
new_gun = random.choice(["bun", "cake"])
new_bullet = random.choice(["pellet", "sprinkle"])
new_pussy = random.choice(["oyster"])

while True:
    f_dir = input("File Directory: ")
    if "dQw4w9WgXcQ" in f_dir:
        print(r"""
        ………………………………………………………………………………„-~~'''''''~~--„„_
    …………………………………………………………………………„-~''-,:::::::::::::::::::''-„
    …………………………………………………………………….,~''::::::::',::::::::::::::::::::|',
    …………………………………………………………………….|::::::,-~'''¯¯¯''''~~--~'''¯'''-,:|
    …………………………………………………………………….'|:::::|: : : : : : : : : : : : : |,'
    …………………………………………………………………….|:::::|: : :-~~---: : : -----: |
    ……………………………………………………………………(¯''~-': : : :'¯°: ',: :|: :°-: :|
    …………………………………………………………………….'''~-,|: : : : : : ~---': : : :,' 
    ………………………………………………………………………..|,: : : : : :-~~--: : ::/ 
    ……………………………………………………………………,-''\':\: :'~„„_: : : : : _,-'
    ………………………………………………………………__„-';;;;;\:''-,: : : :'~---~''/|
    ………………………………………………………__„-~'';;;;;;/;;;;;;;\: :\: : :____/: :',__
    ……………………………………………„-~~~''''¯;;;;;;;;;;;;;;;;;;;;;;;;;',. .''-,:|:::::::|. . |;;;;''-„__
    …………………………………………../;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;;;;;\. . .''|::::::::|. .,';;;;;;;;;;''-„
    …………………………………………,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|;;;;;;;;;;;\. . .\:::::,'. ./|;;;;;;;;;;;;;|
    ………………………………………,-'';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\;;;;;;;;;;;',: : :|¯¯|. . .|;;;;;;;;;,';;|
    …………………………………….„-";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;',;;;;;;;;;;;\. . |:::|. . .'',;;;;;;;;|;;/
    ……………………………………/;;;;;;;;;;;;;;;;;;;;;;;;;;|;;;;;;;;;;;;;;\;;;;;;;;;;;\. .|:::|. . . |;;;;;;;;|/
    …………………………………./;;,-';;;;;;;;;;;;;;;;;;;;;;,';;;;;;;;;;;;;;;;;,;;;;;;;;;;|. .\:/. . . .|;;;;;;;;|
    …………………………………/;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;'',: |;|. . . . \;;;;;;;|
    ………………………………„~'';;;;;;;;;;;;;;;;;;;;;,-'';;;;;;;;;;;;;;;;;;;;;;;;;;\;;;;;;;;|.|;|. . . . .|;;;;;;;|
    …………………………..„~'';;;;;;;;;;;;;;;;;;;;;;,-';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;',;;;;;;| |:|. . . . |\;;;;;;;|
    ………………………….,';;;;;;;;;;;;;;;;;;;;;;;;/;;;,-';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;;| |:|. . . .'|;;',;;;;;|
    …………………………|;,-';;;;;;;;;;;;;;;;;;;,-';;;,-';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;;;| |:|. . .,';;;;;',;;;;|_
    …………………………/;;;;;;;;;;;;;;;;;,-'_;;;;;;,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|;;;;|.|:|. . .|;;;;;;;|;;;;|''''~-„
    ………………………./;;;;;;;;;;;;;;;;;;/¯'',;;;,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,;;| |:|. . ./;;;;;;;;|;;;|;;;;;;|-„„__
    ……………………../;;;;;;;;;;;;;;;;;,-'…|;;,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;| |:|._,-';;;;;;;;;|;;;;|;;;;;;;;;;;'''-„_
    ……………………/;;;;;;;;;;;;;;;;,-'….,';;,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|.|:|::::'''~--~'''||;;;;;|;;;;;;;;;;,-~''''~--„______
    ………………….,';;;;;;;;;;;;;;;;,'……/;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|.|:|::::::::::::::|;;;;;',;;;;;;;;;''-,: : : : : :'''~-,:'''~~--„
    …………………/;;;;;;;;;;;;;;;,-'……,';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|:|:|::::::::::::::',;;;;;;|¯''''~--„„-~---„„___„-~~'''__''~-\
    ………………,-';;;;;;;;;;;;;;;,'……../ ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|:|:|:::::::::::::::|;;;;;
    MD…..……../;;;;;;;;;;;;;;;;/…….,-;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;|:|:|:::::::::::::::|;;;
        """)

    elif "lightswitch" in f_dir.lower():
        print(r"""
     .----------.
     |   ~ON~   |
     |   ____   |
     |  |.--.|  |
     |  ||  ||  |
     |  ||__||  |
     |  ||\ \|  |
     |  |\ \_\  |
     |  |_\[_]  |
     |          |
     |  ~OFF~   |
     '----------'
        """)

    elif "forehead" in f_dir.lower():
        print(r"""
      .................................  .......                   .    
   .,,,,,,,,,,,,,,,,,,,,,,'',,,'',,,,'.'',,,,,,,,,,,,,,,,,,,,,,,,,,.  
   ';,,,,,,,,,,,,,,,,,;;;;;:clc:,,,''''''',,,;;,,,,,,,,,,,,,,,,,,,,.  
   ';,,,,,,,,,,,,,;,',:;;;:::c::;;;,,,,',,'',;;;;;;;;,,,,,,,,,,,,,,.  
   ';,,,,,,,,,;;;;,,,;:cc:;;;;;;;;;:::clooc,,,;;;;;;;;;;;,,,,,,,,,,.  
   ';,,,,,,;;;;;;''.':::;,'',;cldxkOO0KKKKKkc;;;;;;;;;;;;;;;,,,,,,,.  
   ';,,,,;;;;;;,,,,,;:;;;;coxk0KKKKKKKKKKKKKOl:;;;;;;;;;;;;;;;;,,,,.  
   ';,,;;;;;;:;,,;;;,;:::oO00KKKKKKKKKKKKKKKXO:,;;:::;;;;;;;;;;;;,;.  
  .';;;;;;;:::,,ccc:lddxk0KKKXXKKKKKKKKKKKKKKXk:';::::::;;;;;;;;;;;.  
  .,;;;;;::::;,:llco0KKKKKXXXXXKKKKKKKKKKKKKKKKx;,:cc:::::;;;;;;;;;.  
  .,;;;::::::;,:clcdKKKXXXXXXXXXKKKKKKKKKKKKKK00d;:ccc:cc:::;;;;;;;.  
  .,:;::::::cc;;:c::kKKKXXXXXXXXKKKKKKKKKKKko:''::clcccd0dc::;;;;;;.  
  .,:::::::cccc;;::;l0KKKKKKKKKKKKKKKKKK0d;..,cll:clddlxKkc:::::;;;.  
  .;:::::cccccc:;;:;c0KKKKK000OOOkkkkOK0l',:ldkOklclkkololc::::::;;.  
  .;::::ccccccll:;;;o0KKOo;'''....'';d0Ool:':c:lxxocclokOoccc::::;:.  
  .;:::ccccccllll:,,:OKk:;cccccc:ldxk0KOdl:;ldld0Odl:lokOoccccc::::.  
  .;ccccccccllllccol:o0OkOOOOOOkolkOO0X0ddxxkkOKXKxlclllllllccc::::.  
  .:ccccccclllll:ldxdlOKKK0OkkkxxkO00KXXOOKXXXXXXXklcllllllccccc:::.  
  .:cccccclllllc:okxdokKXXXXXXXXXKK0KKKKKO0KXXXXXXOlcolllllllcccc::'  
  .:ccccclllllllcd0Oxod0KXXXXXXXXKKKKKK0K0O0KKKKKX0lcolllllllcccc::'  
  .:cccccllllllllldO0kokKKKXXXXXKKOxk00000OxdOKKKKKdcllllllllcccc::'  
  .:ccccllllllllllccdkdx00KKKKK0O0kdxxdxOkxdkKXOdOKdllllllllccccc::'  
  .:ccccllllllllllllcoooO0KKKK00KKKXKK0OkkxkkkdokK0ocllllllccccc:::.  
  .::cccclllllllllllllccx00KKkdxdxkkxkOkOO0KKOdOXKxclllllllcccc::::.  
  .:::cccclllllllllllllcok00KK0koldxdxkkkxdodk0XX0lcllllllcccc:::::.  
  .:::ccccllllllllllllllllxO00KKKKOkxl:;,;:lkKXXXxclllllcccccc::::;.  
  .;:::cccccllllllllllllllclxO00KKKKKKKOkxxk0KXX0lclccllccccc::::;;.  
  .;::::ccccclllllllllllllccddxk0KKKKKKK0000KKXXkllc::::;,;::::;;;;.  
  .;;;::::ccccccclllllllllclkOxxkkkO0KKKKKKKKKKOolllc;',;;;,';:;;;;.  
  .;;;;::::cccccccccclllllclkOOOOkxxxxkO0000OOxlclccc:;:::,,,;;;;;;.  
  .;;;;;:::::cccccccccclllcoOOOOOOOOOkxxxxddxxdcccccc:::::::;;;;;;;.  
  .,;;;;;;:::::cccccccccc,:xOO0OO000OOOOOxxkOOo:::c:::::::;;;;;;;;;.  
  .,;;;;;;;;;:::::cccc:;..,dkO00OO000000kxkO0Oxo,';::::;;;;;;;;;;,;.  
  .,,,,;;;;;;;;:::::;'.   ..;dO00000KK000000K000c.....',;;;;;,;,,,,.  
  .,,,,,,;;;;;;,''...      ...;d0K0O0KKKKKKKKKK0:..    ....''''',,,.  
  .,,,,,,,''....     ...........;oO00KKKKKKKKKKo.........   ........  
  .''........ ....................',:ok0KKKKKOc....................   
  .....................................,:looc,.....................   
        """)
    try:
        with open(f_dir, 'r') as f:
            f_dir_fin = f_dir.replace(".txt", "_clean_version.txt")
            print(f_dir_fin)
            f_doc = f.read()
            f_cont = f_doc.lower()
            f_cont = f_cont.replace("arse", new_arse)
            f_cont = f_cont.replace("ass", new_ass)
            f_cont = f_cont.replace("alcohol", new_alcohol)
            f_cont = f_cont.replace("bastard", new_bastard)
            f_cont = f_cont.replace("bitch", new_bitch)
            f_cont = f_cont.replace("bollocks", new_bollocks)
            f_cont = f_cont.replace("bugger", new_bugger)
            f_cont = f_cont.replace("balls", new_balls)
            f_cont = f_cont.replace("christ", new_christ)
            f_cont = f_cont.replace("crap", new_crap)
            f_cont = f_cont.replace("cunt", new_cunt)
            f_cont = f_cont.replace("cum", new_cum)
            f_cont = f_cont.replace("damn", new_damn)
            f_cont = f_cont.replace("drug", new_drug)
            f_cont = f_cont.replace("dick", new_dick)
            f_cont = f_cont.replace("drink", new_drink)
            f_cont = f_cont.replace("fuck", new_fuck)
            f_cont = f_cont.replace("god", new_god)
            f_cont = f_cont.replace("gang", new_gang)
            f_cont = f_cont.replace("hell", new_hell)
            f_cont = f_cont.replace("ho ", new_ho)
            f_cont = f_cont.replace("jesus", new_jesus)
            f_cont = f_cont.replace("jizz", new_jizz)
            f_cont = f_cont.replace("nigga", new_nigga)
            f_cont = f_cont.replace("nigger", new_nigger)
            f_cont = f_cont.replace("nut", new_nut)
            f_cont = f_cont.replace("prick", new_prick)
            f_cont = f_cont.replace("shit", new_shit)
            f_cont = f_cont.replace("sex", new_sex)
            f_cont = f_cont.replace("slut", new_slut)
            f_cont = f_cont.replace("twat", new_twat)
            f_cont = f_cont.replace("thot", new_thot)
            f_cont = f_cont.replace("tits", new_tits)
            f_cont = f_cont.replace("whore", new_whore)
            f_cont = f_cont.replace("skank", new_skank)
            f_cont = f_cont.replace("virgin", new_virgin)
            f_cont = f_cont.replace("smoke", new_smoke)
            f_cont = f_cont.replace("cuck", new_cuck)
            f_cont = f_cont.replace("rape", new_rape)
            f_cont = f_cont.replace("raping", new_raping)
            f_cont = f_cont.replace("phat", new_phat)
            f_cont = f_cont.replace("gun", new_gun)
            f_cont = f_cont.replace("bullet", new_bullet)
            f_cont = f_cont.replace("pussy", new_pussy)



        with open(f_dir_fin, "w") as f2:
            f2.write(f_cont)
            print("Succesfully Kidzbopified")
        break
    except:
        print("No Text File Found!")
        print("Try Again!")


